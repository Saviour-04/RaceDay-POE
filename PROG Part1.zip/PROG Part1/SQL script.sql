
USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'RaceDayDB')
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END
GO


CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO


-- Table 1: User
CREATE TABLE [User] (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    PhoneNumber NVARCHAR(20) NULL,
    DateOfBirth DATE NULL,
    [Role] NVARCHAR(20) NOT NULL CHECK ([Role] IN ('Organiser', 'Participant')),
    ProfilePictureUrl NVARCHAR(500) NULL,
    CreatedAt DATETIME DEFAULT GETDATE() NOT NULL,
    IsActive BIT DEFAULT 1 NOT NULL
);
GO

-- Table 2: Event
CREATE TABLE [Event] (
    EventID INT IDENTITY(1,1) PRIMARY KEY,
    OrganiserID INT NOT NULL,
    [Name] NVARCHAR(200) NOT NULL,
    [Description] NVARCHAR(1000) NULL,
    EventDate DATETIME NOT NULL,
    [Location] NVARCHAR(200) NOT NULL,
    Distance DECIMAL(5,2) NOT NULL,
    EventType NVARCHAR(20) NOT NULL CHECK (EventType IN ('Run', 'Walk', 'Cycle')),
    BannerImageUrl NVARCHAR(500) NULL,
    MaxParticipants INT NULL,
    CreatedAt DATETIME DEFAULT GETDATE() NOT NULL,
    IsActive BIT DEFAULT 1 NOT NULL,
    CONSTRAINT FK_Event_Organiser FOREIGN KEY (OrganiserID) REFERENCES [User](UserID),
    CONSTRAINT CK_Event_Distance CHECK (Distance > 0)
);
GO

-- Table 3: Category
CREATE TABLE [Category] (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    EventID INT NOT NULL,
    [Name] NVARCHAR(50) NOT NULL,
    [Description] NVARCHAR(200) NULL,
    MinAge INT NULL,
    MaxAge INT NULL,
    MinDistance DECIMAL(5,2) NULL,
    MaxDistance DECIMAL(5,2) NULL,
    EntryFee DECIMAL(10,2) DEFAULT 0 NOT NULL,
    CONSTRAINT FK_Category_Event FOREIGN KEY (EventID) REFERENCES [Event](EventID),
    CONSTRAINT CK_Category_AgeRange CHECK (MinAge IS NULL OR MaxAge IS NULL OR MinAge <= MaxAge),
    CONSTRAINT CK_Category_EntryFee CHECK (EntryFee >= 0)
);
GO

-- Table 4: Enrolment
CREATE TABLE [Enrolment] (
    EnrolmentID INT IDENTITY(1,1) PRIMARY KEY,
    ParticipantID INT NOT NULL,
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    EnrolmentDate DATETIME DEFAULT GETDATE() NOT NULL,
    [Status] NVARCHAR(20) DEFAULT 'Pending' NOT NULL CHECK ([Status] IN ('Pending', 'Confirmed', 'Cancelled', 'Completed')),
    BibNumber NVARCHAR(20) NULL,
    CONSTRAINT FK_Enrolment_Participant FOREIGN KEY (ParticipantID) REFERENCES [User](UserID),
    CONSTRAINT FK_Enrolment_Event FOREIGN KEY (EventID) REFERENCES [Event](EventID),
    CONSTRAINT FK_Enrolment_Category FOREIGN KEY (CategoryID) REFERENCES [Category](CategoryID),
    CONSTRAINT UQ_Enrolment_ParticipantEvent UNIQUE (ParticipantID, EventID)
);
GO

-- Table 5: Result
CREATE TABLE [Result] (
    ResultID INT IDENTITY(1,1) PRIMARY KEY,
    EnrolmentID INT NOT NULL,
    FinishTime TIME NULL,
    FinishPosition INT NULL,
    OverallPosition INT NULL,
    IsPublished BIT DEFAULT 0 NOT NULL,
    Notes NVARCHAR(500) NULL,
    CONSTRAINT FK_Result_Enrolment FOREIGN KEY (EnrolmentID) REFERENCES [Enrolment](EnrolmentID),
    CONSTRAINT UQ_Result_Enrolment UNIQUE (EnrolmentID)
);
GO

CREATE INDEX IX_Event_OrganiserID ON [Event](OrganiserID);
CREATE INDEX IX_Event_EventDate ON [Event](EventDate);
CREATE INDEX IX_Event_EventType ON [Event](EventType);
CREATE INDEX IX_Category_EventID ON [Category](EventID);
CREATE INDEX IX_Enrolment_ParticipantID ON [Enrolment](ParticipantID);
CREATE INDEX IX_Enrolment_EventID ON [Enrolment](EventID);
CREATE INDEX IX_Enrolment_CategoryID ON [Enrolment](CategoryID);
CREATE INDEX IX_Result_EnrolmentID ON [Result](EnrolmentID);
CREATE INDEX IX_User_Email ON [User](Email);
GO

--  Organisers
INSERT INTO [User] (Email, PasswordHash, FirstName, LastName, PhoneNumber, DateOfBirth, [Role])
VALUES
    ('john.organiser@race.co.za', 'hashed_password_1', 'John', 'Organiser', '+27111234567', '1980-05-15', 'Organiser'),
    ('sarah.events@race.co.za', 'hashed_password_2', 'Sarah', 'Events', '+27821234567', '1985-08-22', 'Organiser');
GO

-- Participants
INSERT INTO [User] (Email, PasswordHash, FirstName, LastName, PhoneNumber, DateOfBirth, [Role])
VALUES
    ('mike.runner@email.com', 'hashed_password_3', 'Mike', 'Runner', '+27331234567', '1990-03-10', 'Participant'),
    ('lisa.cyclist@email.com', 'hashed_password_4', 'Lisa', 'Cyclist', '+27441234567', '1995-07-20', 'Participant');
GO

--  Events
INSERT INTO [Event] (OrganiserID, [Name], [Description], EventDate, [Location], Distance, EventType, MaxParticipants)
VALUES
    (1, 'Comrades Marathon 2026', 'The ultimate human race - 90km between Pietermaritzburg and Durban', '2026-06-15 05:30:00', 'Pietermaritzburg to Durban', 90.00, 'Run', 25000),
    (1, 'Cape Town Cycle Tour 2026', 'The world''s largest timed cycle race - 109km around Cape Town', '2026-03-08 06:00:00', 'Cape Town', 109.00, 'Cycle', 35000),
    (2, 'Soweto Marathon 2026', 'Iconic 42.2km through the heart of Soweto', '2026-11-01 06:00:00', 'Soweto, Johannesburg', 42.20, 'Run', 15000);
GO

-- Insert Categories (3 for Comrades, 2 for Cycle Tour, 3 for Soweto)
INSERT INTO [Category] (EventID, [Name], [Description], MinAge, MaxAge, EntryFee)
VALUES
    -- Comrades Categories
    (1, 'Under 20', 'For runners aged 19 and under', 0, 19, 500.00),
    (1, 'Senior', 'For runners aged 20-39', 20, 39, 750.00),
    (1, 'Master', 'For runners aged 40 and above', 40, NULL, 600.00),
    -- Cape Town Cycle Tour Categories
    (2, 'Standard Entry', 'General entry for all cyclists', NULL, NULL, 350.00),
    (2, 'Elite', 'For competitive cyclists with racing license', NULL, NULL, 500.00),
    -- Soweto Marathon Categories
    (3, 'Under 20', 'For runners aged 19 and under', 0, 19, 300.00),
    (3, 'Senior', 'For runners aged 20-39', 20, 39, 450.00),
    (3, 'Master', 'For runners aged 40 and above', 40, NULL, 400.00);
GO

-- Insert Enrolments
INSERT INTO [Enrolment] (ParticipantID, EventID, CategoryID, [Status], BibNumber)
VALUES
    (3, 1, 2, 'Confirmed', '1001'),  -- Mike in Comrades Senior
    (3, 2, 4, 'Pending', NULL),       -- Mike in Cycle Tour Standard
    (4, 1, 3, 'Confirmed', '1002'),  -- Lisa in Comrades Master
    (4, 3, 5, 'Confirmed', '2001');  -- Lisa in Soweto Senior
GO

-- Insert Results (for 2 confirmed enrolments)
INSERT INTO [Result] (EnrolmentID, FinishTime, FinishPosition, OverallPosition, IsPublished, Notes)
VALUES
    (1, '06:45:30', 5, 47, 1, 'Strong performance, finished in top 50'),
    (3, '07:30:15', 12, 89, 1, 'Good race, consistent pacing');
GO


-- Query 1:  all users
PRINT '--- ALL USERS ---';
SELECT UserID, FirstName, LastName, Email, [Role] FROM [User];
GO

-- Query 2: See all events with organiser names
PRINT '--- ALL EVENTS WITH ORGANISERS ---';
SELECT e.EventID, e.Name, e.EventDate, e.Location, e.Distance, e.EventType,
       u.FirstName + ' ' + u.LastName AS OrganiserName
FROM [Event] e
JOIN [User] u ON e.OrganiserID = u.UserID;
GO

-- Query 3: See all enrolments with participant and event details
PRINT '--- ALL ENROLMENTS ---';
SELECT en.EnrolmentID, 
       p.FirstName + ' ' + p.LastName AS Participant,
       ev.Name AS EventName, 
       c.Name AS Category,
       en.Status, 
       en.BibNumber
FROM [Enrolment] en
JOIN [User] p ON en.ParticipantID = p.UserID
JOIN [Event] ev ON en.EventID = ev.EventID
JOIN [Category] c ON en.CategoryID = c.CategoryID;
GO

-- Query 4: See all results with participant details
PRINT '--- ALL RESULTS ---';
SELECT r.ResultID, 
       p.FirstName + ' ' + p.LastName AS Participant,
       ev.Name AS EventName, 
       c.Name AS Category,
       r.FinishTime, 
       r.FinishPosition, 
       r.OverallPosition, 
       CASE WHEN r.IsPublished = 1 THEN 'Published' ELSE 'Draft' END AS Status
FROM [Result] r
JOIN [Enrolment] en ON r.EnrolmentID = en.EnrolmentID
JOIN [User] p ON en.ParticipantID = p.UserID
JOIN [Event] ev ON en.EventID = ev.EventID
JOIN [Category] c ON en.CategoryID = c.CategoryID;
GO

-- Query 5: Count of enrolments per event
PRINT '--- ENROLMENT COUNTS PER EVENT ---';
SELECT ev.Name AS EventName, COUNT(en.EnrolmentID) AS TotalEnrolments
FROM [Event] ev
LEFT JOIN [Enrolment] en ON ev.EventID = en.EventID
GROUP BY ev.Name
ORDER BY TotalEnrolments DESC;
GO

-- Query 6: Find all participants in Comrades Marathon
PRINT '--- PARTICIPANTS IN COMRADES MARATHON ---';
SELECT p.FirstName + ' ' + p.LastName AS Participant,
       c.Name AS Category,
       en.Status
FROM [Enrolment] en
JOIN [User] p ON en.ParticipantID = p.UserID
JOIN [Category] c ON en.CategoryID = c.CategoryID
JOIN [Event] e ON en.EventID = e.EventID
WHERE e.Name = 'Comrades Marathon 2026';
GO

PRINT '=========================================';
PRINT 'DATABASE SETUP COMPLETE!';
PRINT 'ALL TABLES CREATED WITH SEED DATA';
PRINT '=========================================';