﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public AccountController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            // 1. Connect to the API
            var client = _httpClientFactory.CreateClient("RaceDayAPI");

            // 2. Send the login request
            var loginData = new { Email = email, Password = password };
            var content = new StringContent(JsonSerializer.Serialize(loginData), Encoding.UTF8, "application/json");

            var response = await client.PostAsync("api/auth/login", content);

            // 3. If login is successful
            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();
                var user = JsonSerializer.Deserialize<LoginResponse>(responseString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (user != null)
                {
                    // Save the user's info in the browser session
                    HttpContext.Session.SetInt32("UserId", user.UserId);
                    HttpContext.Session.SetString("UserRole", user.Role);
                    HttpContext.Session.SetString("FirstName", user.FirstName ?? "");

                    // Redirect to the home page
                    return RedirectToAction("Index", "Home");
                }
            }

            // 4. If login fails, show an error
            ViewBag.Error = "Invalid email or password.";
            return View();
        }

        // Logout method
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }

    // This class matches the data your API sends back
    public class LoginResponse
    {
        public int UserId { get; set; }
        public string Role { get; set; }
        public string FirstName { get; set; }
    }
}