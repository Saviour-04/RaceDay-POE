﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;

namespace RaceDayMVC.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public DashboardController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        // This loads the Dashboard page
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login", "Account");

            var client = _httpClientFactory.CreateClient("RaceDayAPI");
            var response = await client.GetAsync("api/events");

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();
                var events = JsonSerializer.Deserialize<List<EventResponse>>(responseString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                return View(events);
            }
            return View(new List<EventResponse>());
        }

        // This opens the Create Event form page
        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login", "Account");
            return View();
        }

        // This handles what happens when you click "Submit" on the form
        [HttpPost]
        public async Task<IActionResult> Create(string name, string description, DateTime eventDate, string location, decimal distance, string eventType, IFormFile bannerImage)
        {
            var client = _httpClientFactory.CreateClient("RaceDayAPI");

            // 1. Send event details to the API
            var newEvent = new
            {
                Name = name,
                Description = description,
                EventDate = eventDate,
                Location = location,
                Distance = distance,
                EventType = eventType
            };

            var content = new StringContent(JsonSerializer.Serialize(newEvent), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("api/events", content);

            if (response.IsSuccessStatusCode)
            {
                var responseString = await response.Content.ReadAsStringAsync();
                var createdEvent = JsonSerializer.Deserialize<EventResponse>(responseString, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                // 2. If the user uploaded an image, send it to the API's upload endpoint
                if (bannerImage != null && bannerImage.Length > 0 && createdEvent != null)
                {
                    using var formData = new MultipartFormDataContent();
                    using var fileStream = bannerImage.OpenReadStream();
                    var fileContent = new StreamContent(fileStream);

                    formData.Add(fileContent, "file", bannerImage.FileName);

                    await client.PostAsync($"api/events/{createdEvent.EventId}/upload-banner", formData);
                }

                return RedirectToAction("Index");
            }

            ViewBag.Error = "Failed to create event. Check API.";
            return View();
        }
    }
}