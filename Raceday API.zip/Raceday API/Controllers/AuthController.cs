﻿using BCrypt.Net;
using Microsoft.AspNetCore.Mvc;
using RacedayAPI; // ⚠️ Make sure this matches your exact namespace!
using RaceDayAPI.Models;

namespace RacedayAPI.Controllers // ⚠️ If this has a red line, change it to just "namespace RacedayAPI"
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly RaceDayDBContext _context;

        public AuthController(RaceDayDBContext context)
        {
            _context = context;
        }
    }
}

        // ... (the rest of the code we pasted earlier)