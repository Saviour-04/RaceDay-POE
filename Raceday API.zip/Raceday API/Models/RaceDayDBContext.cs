﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace RaceDayAPI.Models
{
    public class RaceDayDBContext : DbContext
    {
        public RaceDayDBContext(DbContextOptions<RaceDayDBContext> options) : base(options)
        {
        }

        // These represent your SQL tables
        public DbSet<User> Users { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Enrolment> Enrolments { get; set; }
        public DbSet<Result> Results { get; set; }
    }
}