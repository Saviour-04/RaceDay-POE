﻿using Microsoft.EntityFrameworkCore;
using RacedayAPI;
using RaceDayAPI.Models; // ⚠️ IMPORTANT: Change this to match your exact namespace! (See below)

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// 1. ADD DATABASE CONNECTION
builder.Services.AddDbContext<RaceDayDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2. ADD SESSION SUPPORT
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// 3. ADD SESSION MIDDLEWARE
app.UseSession();
app.UseAuthorization();
app.MapControllers();

app.Run();